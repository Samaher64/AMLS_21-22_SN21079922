# Brain Tumor Project

## Organization Of The Files

```
brain-tumor-project
|___brain_tumor_project
|   |___dataset
|   |   |___(python files)
|   |___models
|   |   |___(python files)
|   |___utils
|       |___(python files)
|___brain-tumor-dataset
|   |___images
|   |   |___(image files)
|   |___crop-images
|   |   |___(automatically filled by code with cropped images)
|   |___labels.csv
|___main.py
```

##Task1:
The first type of classification model is the binary classification for MRI images into two classes(Tumor,No Tumor). 

#Task2#:
The second type of classification model is the multi-classification for MRI images into four classes(No Tumor,meningioma, glioma, and pituitary tumours)

##To Run:
Copy the dataset into brain-tumor-dataset folder.
Python package: run python main.py to run all the models.

##Role of each file:

dataset/augmentation.py
Performs data augmentation by creating different data generators.
dataset/explore_dataset.py
Performs EDA on the dataset.
dataset/read_dataset.py
reads the dataset.
models/base_model.py
Train KNN and SVM models
models/cnn_model.py
Train different CNN models
models/cnn_utils.py
Utility functions for cnn models
utils/visualization.py
Files or utility functions for visualization 

##Necessary packages or headers:
Tensorflow .
Keras .
NumPy.
Matplotlib.
Pandas_ml.
Sklearn
Scipy.


